# Name: camera

__animations__frames=(
	'📷' '📷' '📷' '📷' '📷' '📷' '📷' '📷' '📸' '📷' '📸'
)
