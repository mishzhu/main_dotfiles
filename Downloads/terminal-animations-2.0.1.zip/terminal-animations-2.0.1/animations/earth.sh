# Name: earth

__animations__frames=(
	'🌍' '🌎' '🌏'
)
