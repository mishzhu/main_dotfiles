# Name: quarter

__animations__frames=(
	'▖' '▘' '▝' '▗'
)
