# Name: trigram

__animations__frames=(
	'☰' '☱' '☳' '☶' '☴'
)
