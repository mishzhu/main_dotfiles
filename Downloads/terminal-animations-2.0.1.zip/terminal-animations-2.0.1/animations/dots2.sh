# Name: standard2

__animations__frames=(
	'   ' '.  ' '.. ' '...' ' ..' '  .'
)
