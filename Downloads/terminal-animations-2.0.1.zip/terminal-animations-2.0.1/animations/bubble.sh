# Name: bubble

__animations__frames=(
	'·' 'o' 'O' 'O' 'o' '·'
)
