# Name: future

__animations__frames=(
	'┤' '┴' '├' '┬'
)
