# Name: arrow2

__animations__frames=(
	'◢' '◣' '◤' '◥'
)
