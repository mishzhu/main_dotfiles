# Name: braille

__animations__frames=(
	'⠁' '⠂' '⠄' '⡀' '⢀' '⠠' '⠐' '⠈'
)
