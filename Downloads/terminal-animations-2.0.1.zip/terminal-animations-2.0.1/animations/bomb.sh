# Name: bomb

__animations__frames=(
	'💣   ' ' 💣  ' '  💣 ' '   💣' '   💣' '   💣' '   💣' '   💣' '   💥' '    ' '    '
)
