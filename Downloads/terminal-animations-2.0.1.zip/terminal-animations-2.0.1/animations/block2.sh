# Name: block2

__animations__frames=(
	'▏' '▎' '▍' '▌' '▋' '▊' '▉' '▉' '▊' '▋' '▌' '▍' '▎' '▏'
)
