# Name: modern

__animations__frames=(
	'●    ' ' ●   ' '  ●  ' '   ● ' '    ●' '   ● ' '  ●  ' ' ●   ' '●    '
)
