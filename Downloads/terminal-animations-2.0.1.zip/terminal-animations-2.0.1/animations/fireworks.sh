# Name: fireworks

__animations__frames=(
	'⢀' '⠠' '⠐' '⠈' '*' '*' ' '
)
