# Name: classic

__animations__frames=(
	'-' '\' '|' '/'
)
