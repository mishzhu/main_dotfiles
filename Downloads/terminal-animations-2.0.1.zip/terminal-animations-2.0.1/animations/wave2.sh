# Name: wave

__animations__frames=(
	'∘∘∘' '∘∘°' '∘°°' '°°°' '°°∘' '°∘∘'
)
