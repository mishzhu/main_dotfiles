# Name: semi

__animations__frames=(
	'◐' '◓' '◑' '◒'
)
