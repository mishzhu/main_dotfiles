# Name: arrow

__animations__frames=(
	'↑' '↗' '→' '↘' '↓' '↙' '←' '↖'
)
