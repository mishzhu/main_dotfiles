# Name: bit

__animations__frames=(
	'●' '⚬'
)
