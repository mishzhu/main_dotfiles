# Name: braille2

__animations__frames=(
	'⣾' '⣽' '⣻' '⢿' '⡿' '⣟' '⣯' '⣷'
)
