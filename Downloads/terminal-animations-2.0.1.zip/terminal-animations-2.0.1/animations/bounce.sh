# Name: bounce

__animations__frames=(
	'.' '·' '·'
)
