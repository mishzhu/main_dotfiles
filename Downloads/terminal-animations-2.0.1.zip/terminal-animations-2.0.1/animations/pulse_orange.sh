# Name: pulse_orange

__animations__frames=(
	'🔸' '🔶' '🟠' '🟠' '🔶'
)
