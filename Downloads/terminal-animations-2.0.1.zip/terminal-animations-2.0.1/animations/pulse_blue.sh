# Name: pulse_blue

__animations__frames=(
	'🔹' '🔷' '🔵' '🔵' '🔷'
)
