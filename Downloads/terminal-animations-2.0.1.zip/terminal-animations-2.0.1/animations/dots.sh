# Name: standard

__animations__frames=(
	'   ' '.  ' '.. ' '...'
)
