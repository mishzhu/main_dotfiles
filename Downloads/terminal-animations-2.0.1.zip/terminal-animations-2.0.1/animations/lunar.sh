# Name: lunar

__animations__frames=(
	'🌕' '🌖' '🌗' '🌘' '🌑' '🌒' '🌓' '🌔'
)
