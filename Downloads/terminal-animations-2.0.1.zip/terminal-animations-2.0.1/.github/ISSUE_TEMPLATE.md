## Program Version

_the version (commit name if cloned) of the program you are using_

## Shell

_your shell and its version here_

## Description

_detailed description of problem or suggestion here_

## How to reproduce problem

_detailed steps on how to reproduce the problem in your shell_

## Extra information

_any extra information that might be useful_
